# JAR Risk–CAM Misalignment | reproducibility starter
Dr. Saeid Homayoun | 2026-10-16

STATUS: METHODS + SYNTHETIC TESTS. **No real-data regressions, JEV installation, replicated FT50 coefficients or publication-ready results.**

Canonical sources, code and results remain in Google Drive and existing GitHub PR #184, not duplicated in public archives. This ZIP contains original contract-validation code, an explicitly SYNTHETIC illustration, the FT50 replication source registry and JAR submission-planning documents. It does not contain restricted raw observations or redistributed third-party source code.

## Reproduction (Python 3.10+; standard library only)
`python -m unittest discover -s tests -v`
`python src/validate_panel.py data/SYNTHETIC_demo.csv`

The synthetic demo is **NOT** a result of applying JEV or any trained scoring model. Input probabilities are contrived for schema testing only.

## Important data model
One row = firm_id × fiscal_year × domain. Keys must be unique. Evidence timestamp <= cutoff; observed future outcomes must be after cutoff. `risk_probability` must be generated separately from chronologically trained, label-blind models. CAM selection, ICFR status and future outcomes must never feed the same-period ex ante features.

`data/CANONICAL_SOURCE_LINKS.csv`: original private Drive sources; never copy their data into public GitHub/Hugging Face.
`docs/FT50_REPLICATION_REGISTRY.csv`: journal literature and code access states; link upstream rather than copying copyrighted packages.
`docs/JAR_DATA_DESCRIPTION_SHEET_TEMPLATE.md`: required provenance description.
`docs/PUBLICATION_PLAN.md`: 16-week submission pathway.

GitHub canonical: https://github.com/Saehon/Saeid-Homayoun/pull/184
Risk engine: https://github.com/Saehon/Saeid-Homayoun/blob/research/jev-ai-audit-proposal/research/jev-ai-audit/common_risk_engine.py
Drive results: https://docs.google.com/spreadsheets/d/1q7IFjPfUT5Wx1tDU3pz_VYHpa941yqCrKiDD3xlrB-Y/edit

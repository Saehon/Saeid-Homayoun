# JAR Publication Plan: Risk–CAM Misalignment
Owner: Dr. Saeid Homayoun | Status: NOT SUBMISSION READY | 16 October 2026

## Central contribution
Independently measured point-in-time account-domain risk versus auditor CAM topic choice; subsequent account-linked reporting problems. Avoid treating CAM nonselection as audit failure, and distinguish prediction from causality.

## Exact milestone sequence (16 weeks)
- Weeks 1–2 — audit original SEC/CAM/ICFR data accessibility, license and extraction dates; verify 609-row candidate grid versus only 11 previously temporally eligible records; document complete missingness and prospective sample; confirm JAR preregistration applicability.
- Weeks 3–4 — materiality/eligibility opportunity set, point-in-time account risk features, 100-case source tracing, blind labeling protocol, and registered analysis decisions when appropriate.
- Weeks 5–6 — corrected Bao baseline (MATLAB/RUSBoost), logistic, domain-specific GBM, Dechow-inspired F-score; set untouched chronological test partition; no JEV superiority assumption.
- Weeks 7–8 — CAM text topic annotation without sharing labels with risk feature construction; risk–CAM gap formal definitions and reliability.
- Weeks 9–10 — independent t+1 domain outcomes and censoring; baseline H1/H2/H3/H4 models only with meaningful events and independent firms; clustered uncertainty.
- Weeks 11–12 — falsification tests, placebo, risk-vs-alignment incremental value, firm/auditor/year heterogeneity, sensitivity to eligibility.
- Weeks 13–14 — full verified Tables 1–6, manuscript Results & Discussion, JAR data-description sheet and machine-readable logs.
- Weeks 15–16 — replication audit from clean checkout, conflict disclosures, author signoff, separate title page/double-anonymized main file, editorial submission decision.

## Publication no-go conditions
- <50 unique firms with point-in-time exposure (proposed operational minimum, not a universal statistical adequacy guarantee); cluster/event sufficiency must be determined by design and power diagnostics.
- No reliable t+1 domain outcomes, no independent CAM eligibility, temporal leakage, inability to reproduce original author benchmarks, inability to verify risk data rights.
- Code and research claims must not present synthetic evidence as real-data empirical results.

## JAR policy gates
Official: https://onlinelibrary.wiley.com/page/journal/1475679x/homepage/ForAuthors.html
At initial submission: data description sheet and restrictions. Upon acceptance: processing code, regressions, table-generation programs, log files, identifier files when feasible, six-year retention commitment. Preregistration policy applies to qualifying primary data (e.g. surveys/experiments) after 1 Jan 2027; determine applicability to new manual coding before fielding it.

## Canonical assets / do not duplicate
Google Drive real data: see data/CANONICAL_SOURCE_LINKS.csv
GitHub research code: https://github.com/Saehon/Saeid-Homayoun/pull/184
JAR manuscript Word: within Google Drive publication folder (stored separately from this ZIP).

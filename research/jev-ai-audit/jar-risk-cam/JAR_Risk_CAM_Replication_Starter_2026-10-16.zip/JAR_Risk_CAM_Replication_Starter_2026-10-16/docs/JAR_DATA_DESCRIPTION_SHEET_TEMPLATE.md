# JAR DATA DESCRIPTION SHEET — REQUIRED TEMPLATE (NOT COMPLETE)
Article: Do Auditors Disclose the Risks That Matter?
Authors: Dr. Saeid Homayoun [coauthors, if any, to approve]

1. Who handled raw data? [NAME/ROLE/DATE: TO COMPLETE]
2. Exact sources, download dates and acquisition method: SEC EDGAR; archival CAM reports; canonical Drive file IDs; each source accession and extraction tool [TO COMPLETE]
3. Are any original observations, labels or files restricted? [PROVIDER/AGREEMENT/RESTRICTIONS: TO COMPLETE]
4. Sample selection by fiscal year and audit jurisdiction; eligible firms and exclusions [TO COMPLETE]
5. Data processing: raw-to-analysis code, checksums, joins, coding manuals and version log [TO COMPLETE]
6. Table reproduction: command-line scripts, pinned versions, seeds, output paths [TO COMPLETE]
7. Firm identifiers: CIK link and alternative permitted keys [TO COMPLETE]
8. Logs: complete execution evidence from raw ingestion through manuscript tables [TO COMPLETE]
9. Data/programs retention: responsible author confirms >= 6 years from publication [PENDING]
10. Preregistration applicability: review primary data creation and newly collected manual labels [PENDING]
11. AI policy: audit if AI use requires disclosure and document model/tool versions [PENDING]

This is a blank template, not a completed JAR submission datasheet.
